import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from './api.service';

interface Message {
  role: 'user' | 'bot';
  text: string;
  sources?: { page: string | number; preview: string }[];
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent {

  selectedFile: File | null = null;
  collectionName: string = '';
  uploadedFilename: string = '';
  uploading = false;
  uploadError = '';

  messages: Message[] = [];
  question = '';
  loading = false;

  constructor(private api: ApiService) {}

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.selectedFile = input.files[0];
      this.uploadError = '';
    }
  }

  uploadFile() {
    if (!this.selectedFile) return;
    this.uploading = true;
    this.uploadError = '';
    this.collectionName = '';
    this.messages = [];

    this.api.uploadPdf(this.selectedFile).subscribe({
      next: (res) => {
        this.collectionName = res.collection_name;
        this.uploadedFilename = res.filename;
        this.uploading = false;
        this.messages.push({
          role: 'bot',
          text: `✅ ${res.filename} uploaded and indexed — ${res.chunks_indexed} chunks ready. Ask me anything about it!`
        });
      },
      error: (err) => {
        this.uploadError = err.error?.detail || 'Upload failed. Is the backend running?';
        this.uploading = false;
      }
    });
  }

  sendQuestion() {
    const q = this.question.trim();
    if (!q || !this.collectionName || this.loading) return;

    this.messages.push({ role: 'user', text: q });
    this.question = '';
    this.loading = true;

    const botMsgIndex = this.messages.length;
    this.messages.push({ role: 'bot', text: '', sources: [] });

    this.api.queryStream(
      q,
      this.collectionName,
      (chunk: string) => {
        this.messages[botMsgIndex].text += chunk;
        this.scrollToBottom();
      },
      (sources: any[]) => {
        this.messages[botMsgIndex].sources = sources;
      },
      () => {
        this.loading = false;
      },
      () => {
        this.messages[botMsgIndex].text = '❌ Something went wrong. Please try again.';
        this.loading = false;
      }
    );
  }

  onEnter(event: KeyboardEvent) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendQuestion();
    }
  }

  scrollToBottom() {
    setTimeout(() => {
      const el = document.getElementById('chat-window');
      if (el) el.scrollTop = el.scrollHeight;
    }, 100);
  }
}